
package web.automation;

/**
 *
 * @author Tuspa
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class WebAutomation {

    public static void main(String[] args) {
       // Set the path to the ChromeDriver executable (if required)
      
        
        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();
        
        try {
            // Task 2: Navigate to Google
            driver.get("https://www.google.com/");
            
            // Wait for the page to load completely (implicit wait can be added if needed)
            Thread.sleep(2000); // Adding a short delay for demonstration purposes
            
            // Task 3: Fetch and Print Website Title
            String actualTitle = driver.getTitle();
            System.out.println("Page Title: " + actualTitle);
            
            // Bonus Task: Validate Title
            String expectedTitle = "Google";
            if (actualTitle.equals(expectedTitle)) {
                System.out.println("Title Matched!");
            } else {
                System.out.println("Title Mismatch!");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
    }
    

